Instructions :

This code defines a Recipe class that stores details about a recipe such as its ingredients, quantities, units, Calories and steps.
It has methods to enter details for a recipe, display a recipe, scale a recipe, reset the quantities of a recipe,calculate Calories and clear a recipe.
The EnterDetails() method prompts the user to enter the number of ingredients and steps, and then initializes the ingredients, quantities, calculate calories and units arrays with the correct size.
It then prompts the user to enter the details for each ingredient and step and stores them in the respective arrays.
The DisplayRecipe() method displays the ingredients and quantities, and then the steps.
The ScaleRecipe(double factor) method multiplies all the quantities in the recipe by a scaling factor.
The ResetQuantities() method divides all the quantities in the recipe by 2.
The ClearRecipe() method resets all the arrays to empty.
The Main() method of the Program class presents the user with a menu of options to interact with the Recipe class. The user can enter details for a recipe,
display a recipe, scale a recipe, reset the quantities of a recipe, or clear a recipe. The program exits when the user chooses the option to exit.

GitHub Link :

https://github.com/ShaquilleMohlahlo/RecipeAppPart2